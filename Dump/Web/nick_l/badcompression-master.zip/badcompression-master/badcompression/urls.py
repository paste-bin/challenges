"""badcompression URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.9/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from django.views.generic.base import RedirectView

import myauth.views
import social.views
import eager_gzip.views

urlpatterns = [
    url(r'^admin/', admin.site.urls),

    url(r'^signup/', myauth.views.signup, name="signup"),
    url(r'^login/', myauth.views.login, name="login"),
    url(r'^logout/', myauth.views.logout, name="logout"),

    url(r'^$', RedirectView.as_view(url='feed/')),
    url(r'^feed/', social.views.feed_page, name='feed_page'),
    url(r'^feed_updates/(?P<updates_since>[0-9]+)', social.views.feed_updates, name='feed_updates'),
    url(r'^status_update/', social.views.status_update, name='status_update'),

    url(r'^monitoring/(?P<updates_since>[0-9]+)', eager_gzip.views.leak_compressed_size, name='monitoring'),
    url(r'^monitoring/', eager_gzip.views.monitoring, name='monitoring_page'),
]
