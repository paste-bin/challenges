from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.http import JsonResponse
from models import StatusUpdate
from forms import StatusUpdateForm
from collections import OrderedDict

@login_required
def feed_page(request):
	form = StatusUpdateForm()
	show_flag = request.user.username == settings.TARGET_ACCOUNT_NAME
	return render(request, 'feed.html', context={'form': form, 'show_flag': show_flag})

@login_required
def feed_updates(request, updates_since):
	session_token = "(("+request.session.session_key+"))"
	updates = StatusUpdate.objects.filter(id__gt=updates_since).values('text', 'owner__username', 'id')
	d = OrderedDict()
	d['updates'] = list(updates)
	d['token'] = session_token
	return JsonResponse(d)

@login_required
def status_update(request):
	if request.method != 'POST':
		raise Exception("You must use POST to post")
	form = StatusUpdateForm(request.POST)
	if form.is_valid():
		text = form.cleaned_data['text']
		owner = request.user
		StatusUpdate.objects.create(owner=owner, text=text)
	return redirect('feed_page')
