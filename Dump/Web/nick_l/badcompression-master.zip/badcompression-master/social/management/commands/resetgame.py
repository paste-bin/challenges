from django.core.management.base import BaseCommand
from django.conf import settings

from django.contrib.auth.models import User
from eager_gzip.models import *
from social.models import *

class Command(BaseCommand):
	help = 'Wipes all data and creates initial game data.'

	def handle(self, *args, **options):
		self.wipe()
		self.make_users()
		self.add_hints()

	def wipe(self):
		to_delete = [User, LogEntry, StatusUpdate]
		for model in to_delete:
			self.stdout.write("Deleting {}".format(model.__name__))
			model.objects.all().delete()

	def make_users(self):
		self.stdout.write("Creating user {} with password {}".format(
			settings.TARGET_ACCOUNT_NAME,
			settings.TARGET_ACCOUNT_PASSWORD,
		))
		self.admin = User.objects.create_user(settings.TARGET_ACCOUNT_NAME, password=settings.TARGET_ACCOUNT_PASSWORD)

	def add_hints(self):
		self.stdout.write("Adding hints")
		StatusUpdate.objects.create(owner=self.admin, text="Hello, World!")
		StatusUpdate.objects.create(owner=self.admin, text="""
Looks like I've been able to decrease bandwidth usage fairly well. https://www.dropbox.com/s/qrg0qbtgej6aq6m/secret.png?dl=0
""")
		StatusUpdate.objects.create(owner=self.admin, text="""
If I keep making awesome optimisations like that, maybe soon we'll have enough spare bandwidth to support images.
""")
