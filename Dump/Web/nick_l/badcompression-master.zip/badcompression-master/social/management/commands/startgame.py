from django.core.management.base import BaseCommand
from django.conf import settings

import requests
import json
import time

LOGIN_URL = "http://127.0.0.1:8000/login/"
FEED_URL = "http://127.0.0.1:8000/feed/"
UPDATE_URL = "http://127.0.0.1:8000/feed_updates/"

class Command(BaseCommand):
	help = 'Simulates the actions of the admin user'

	def handle(self, *args, **options):
		self.cookies = None
		self.biggest_id = 0
		self.login()
		while True:
			self.update()
			time.sleep(1)

	def login(self):
		response = requests.post(LOGIN_URL, {'username': settings.TARGET_ACCOUNT_NAME, 'password': settings.TARGET_ACCOUNT_PASSWORD})
		self.cookies = response.history[0].cookies
		print self.cookies['sessionid']

	def update(self):
		response = requests.get(UPDATE_URL+str(self.biggest_id), cookies=self.cookies)
		updates = json.loads(response.content)['updates']
		for update in updates:
			if update['id'] > self.biggest_id:
				self.biggest_id = update['id']
