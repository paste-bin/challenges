from django import forms

class StatusUpdateForm(forms.Form):
	text = forms.CharField(max_length=10000, required=True, widget=forms.Textarea)
