import requests
import json
import time

LOGIN_URL = "http://127.0.0.1:8000/login/"
FEED_URL = "http://127.0.0.1:8000/feed/"
UPDATE_URL = "http://127.0.0.1:8000/feed_updates/"
ADMIN_USER = "admin"
ADMIN_PASSWORD = "123"

cookies = None
biggest_id = 0

def login():
	global cookies
	response = requests.post(LOGIN_URL, {'username': ADMIN_USER, 'password': ADMIN_PASSWORD})
	cookies = response.history[0].cookies
	print cookies['sessionid']

def update():
	global biggest_id
	global cookies
	response = requests.get(UPDATE_URL+str(biggest_id), cookies=cookies)
	updates = json.loads(response.content)['updates']
	for update in updates:
		if update['id'] > biggest_id:
			biggest_id = update['id']

def main():
	login()
	while True:
		update()
		time.sleep(1)

if __name__ == '__main__':
	main()
