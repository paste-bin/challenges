from django.shortcuts import render, redirect
from forms import LoginForm, SignupForm
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login as login_user, logout as logout_user

def signup(request):
	form = SignupForm()
	if request.method == 'POST':
		form = SignupForm(request.POST)
		if form.is_valid():
			username = form.cleaned_data['username']
			password = form.cleaned_data['password']
			new_user = User.objects.create_user(username, password=password)
			user = authenticate(username=username, password=password)
			login_user(request, user)
			return redirect('feed_page')
	return render(request, 'signup.html', context={'form': form})

def login(request):
	form = LoginForm()
	if request.method == 'POST':
		form = LoginForm(request.POST)
		if form.is_valid():
			login_user(request, form.cleaned_data['user'])
			return redirect('feed_page')
	return render(request, 'login.html', context={'form': form})

def logout(request):
	logout_user(request)
	return redirect(login)

