from django import forms
from django.contrib.auth import authenticate

class SignupForm(forms.Form):
	username = forms.CharField(label='Username', max_length=16, required=True)
	password = forms.CharField(label='Password', widget=forms.PasswordInput, required=True)
	password_confirm = forms.CharField(label='Password (confirm)', widget=forms.PasswordInput, required=True)

	def clean_password_confirm(self):
		if self.cleaned_data['password_confirm'] != self.cleaned_data['password']:
			raise forms.ValidationError('Passwords don\'t match')


class LoginForm(forms.Form):
	username = forms.CharField(label='Username', max_length=16)
	password = forms.CharField(label='Password', widget=forms.PasswordInput)

	def clean(self):
		cleaned_data = super(LoginForm, self).clean()
		user = authenticate(username=cleaned_data.get('username'), password=cleaned_data.get('password'))
		if user is None:
			raise forms.ValidationError('Login is bad')
		else:
			cleaned_data['user'] = user
		return cleaned_data
