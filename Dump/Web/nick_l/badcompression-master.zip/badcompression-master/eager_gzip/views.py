from django.shortcuts import render
from models import LogEntry

from django.http import JsonResponse

def leak_compressed_size(request, updates_since):
	entries = list(LogEntry.objects.filter(id__gt=updates_since).order_by('-id').values('id', 'user__username', 'size', 'compressed_size')[:33])
	return JsonResponse({'logs': entries[::-1]})

def monitoring(request):
	return render(request, 'monitoring.html')