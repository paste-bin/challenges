# badcompression

## setup

You probably don't want to use the default admin password for the app,
because it is easier to guess that password than to win the wargame, so
set it in `badcompression/settings.py`.

You probably don't want to use a sqlite database, because to exploit the bug
in this wargame, you have to do a lot of writes very quickly, and I've run into
a 'database is locked' error once or twice when exploiting the bug myself.

You probably don't want to have DEBUG set to True, either, because then you 
can just cause any page to error and skip a few steps in the wargame.

To populate the database with initial data, run `./manage.py resetgame`.
Start the app with your preferred way to start a django app (`./manage.py runserver`
is not advisable).
Start the game (simulate user action) with `./manage.py startgame`

As-is, the game only supports one player, because the information leak is global
and if more than one person is trying to hack the admin, the game becomes unplayable.

## vulnerability

The main vulnerability in this app, and the one which is meant to take the most
time to exploit, is that the app leaks the compressed size of each request. It
also sends you your session cookie in the payload of a particular AJAX endpoint.

The endpoint in question is the newsfeed-update endpoint, which is hit every second
by the admin account. The data sent in this endpoint is partially user controlled
(users can post to the newsfeed). A post which contains the partial or complete 
session cookie is likely to compress better than a post which doesn't, and it is
possible to use this to guess the cookie.

## exploit

The file called breaker.py is a PoC exploit for this app. You need to supply it
with a valid login cookie, after which it will gradually steal the login cookie of
the admin account.


