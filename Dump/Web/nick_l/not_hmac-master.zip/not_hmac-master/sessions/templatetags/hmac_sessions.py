from django import template
import sessions.hmac
from django.core.urlresolvers import reverse

register = template.Library()

@register.simple_tag
def secure_url(uri, user):
	if not uri.startswith('/'):
		uri = reverse(uri)
	return sessions.hmac.sign_uri(uri, user)
