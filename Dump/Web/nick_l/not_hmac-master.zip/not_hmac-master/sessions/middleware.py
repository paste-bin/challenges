from django.conf import settings
from django.shortcuts import redirect
from django.contrib.auth.models import User
import time
import urllib
import hashlib

import hmac

class HmacSessionMiddleware(object):
	def __init__(self):
		return

	def hmac_fail(self, request, reason):
		if self.is_anon(request):
			return
		return redirect("/login/?m=" + reason)

	def is_anon(self, request):
		if request.path in settings.ANONYMOUS_ACCESS_PATHS:
			return True
		if request.path + "/" in settings.ANONYMOUS_ACCESS_PATHS:
			return True
		return False

	def process_request(self, request):
		if 'hmac' not in request.GET:
			return self.hmac_fail(request, "")
		if 'xp' not in request.GET:
			return self.hmac_fail(request, "missing_time")
		if 'user' not in request.GET:
			return self.hmac_fail(request, "missing_user")

		request_time = float(request.GET["xp"])
		if time.time() > request_time and not self.is_anon(request) and not request.path.startswith('/logout'):
			return self.login_redirect(request)

		request.GET = request.GET.copy()
		user_hmac = request.GET["hmac"]
		del request.GET["hmac"]

		user_id = request.GET["user"]
		user = User.objects.get(id=user_id)

		if not user.is_staff:
			for p in settings.STAFF_ONLY:
				if request.path.startswith(p):
					return self.hmac_fail(request, "staff_only")
		if not user.is_superuser:
			for p in settings.SUPERUSER_ONLY:
				if request.path.startswith(p):
					return self.hmac_fail(request, "superuser_only")


		uri = hmac.normalise_uri(request.path + '?' + request.GET.urlencode(), user)
		actual_hmac = hmac.get_hmac(uri, user)

		if actual_hmac != user_hmac:
			return self.hmac_fail(request, "tampering")

		request.user = user

	def login_redirect(self, request):
		user_id = request.GET["user"]
		user = User.objects.get(id=user_id)
		to = request.path + '?' + urllib.urlencode(sorted(request.GET.items()))
		login_uri = "/login/?m=expired&" + urllib.urlencode({'zzz': to})
		return redirect(hmac.sign_uri(login_uri, user))



		