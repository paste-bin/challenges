from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User

class CryptoSecret(models.Model):
	secret = models.CharField(max_length=100)
	user = models.OneToOneField(User, related_name='secret')

	@property
	def hidden_secret(self):
	    if self.user.is_staff:
	    	return '*' * len(self.secret)
	    else:
	    	return self.secret
	
