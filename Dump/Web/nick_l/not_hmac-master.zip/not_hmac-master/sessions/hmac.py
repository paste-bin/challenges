from django.conf import settings
from django.shortcuts import redirect
from django.core.urlresolvers import reverse
import time
import urllib
import urlparse
import hashlib
import random
import string

def concat_args(items):
	s = ""
	for key, value in items:
		if s:
			s += '&'
		s += str(key) + '=' + str(value)
	return s

def add_meta_args(uri, user):
	parsed = urlparse.urlparse(uri)
	if '?' not in uri:
		uri += '?'
	GET = urlparse.parse_qs(parsed.query) or {}
	if 'xp' not in GET:
		if not uri.endswith('?'):
			uri += '&xp='
		else:
			uri += 'xp='
		uri += str(time.time() + settings.LINK_EXPIRY_SECONDS)
	if 'user' not in GET:
		uri += '&user=' + str(user.id)
	return uri

def normalise_uri(uri, user):
	parsed = urlparse.urlparse(add_meta_args(uri, user))
	GET = urlparse.parse_qs(parsed.query) or {}
	if "hmac" in GET:
		del GET["hmac"]
	keys = sorted(GET.keys())
	items = [(key, GET[key][0]) for key in keys]
	return parsed.path + '?' + concat_args(items)

def sign_uri(uri, user):
	uri = add_meta_args(uri, user)
	return uri + '&hmac=' + get_hmac(normalise_uri(uri, user), user)

def get_hmac(uri, user):
	print uri
	return hashlib.md5(uri+user.secret.secret).hexdigest()[-settings.HMAC_LENGTH:]

def generate_secret(length=settings.HMAC_KEY_LENGTH):
	return ''.join(random.SystemRandom().choice(string.digits + "abcdef") for _ in range(length))

def logout_user(request):
	if request.user.is_superuser:
		request.user.secret.secret = generate_secret(length=settings.HMAC_SUPERUSER_KEY_LENGTH)
	else:
		request.user.secret.secret = generate_secret()
	request.user.secret.save()
	return redirect('/login/?m=logout')

def login_user(request, user):
	if "zzz" in request.GET:
		print "\nattempting redirect\n"
		parsed = urlparse.urlparse(request.GET["zzz"])
		GET = urlparse.parse_qs(parsed.query) or {}
		GET = {x: GET[x][0] for x in GET}
		print GET
		given_hmac = GET["hmac"]

		old_uri = normalise_uri(request.GET["zzz"], user)
		old_hmac = get_hmac(old_uri, user)

		print given_hmac
		print old_uri
		print old_hmac
		if given_hmac == old_hmac:
			print "Redirecting"
			del GET["hmac"]
			GET["xp"] = time.time() + settings.LINK_EXPIRY_SECONDS

			return redirect(sign_uri(parsed.path + '?' + concat_args(GET.items()), user))


	url = sign_uri(reverse('home'), user)
	return redirect(url)

