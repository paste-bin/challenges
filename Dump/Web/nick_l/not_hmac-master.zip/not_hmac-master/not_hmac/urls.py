"""not_hmac URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.9/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin

import myauth.views
import btc.views

urlpatterns = [
    url(r'^admin/', admin.site.urls, name="admin"),

    url(r'^signup/', myauth.views.signup, name="signup"),
    url(r'^login/', myauth.views.login, name="login"),
    url(r'^logout/', myauth.views.logout, name="logout"),
    url(r'^account/', myauth.views.account, name="account"),

    url(r'^$', btc.views.home, name="home"),
    url(r'^security/', btc.views.security, name="security"),
    url(r'^search/', btc.views.search, name="search"),
    url(r'^send_message/', btc.views.send_message, name="send_message"),
    url(r'^read_messages/', btc.views.read_messages, name="read_messages"),
    url(r'^user_approval/', btc.views.user_approval, name="user_approval"),
]
