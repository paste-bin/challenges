from django.shortcuts import render, redirect
from forms import LoginForm, SignupForm, ProfileForm
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from sessions.hmac import login_user, logout_user
import sessions
import sessions.hmac
import models

def signup(request):
	form = SignupForm()
	if request.method == 'POST':
		form = SignupForm(request.POST)
		if form.is_valid():
			username = form.cleaned_data['username']
			password = form.cleaned_data['password']
			new_user = User.objects.create_user(username, password=password)
			user = authenticate(username=username, password=password)
			user.secret = sessions.models.CryptoSecret.objects.create(secret=sessions.hmac.generate_secret(), user=user)
			user.profile = models.Profile.objects.create(user=user)
			user.save()
			return login_user(request, user)
	return render(request, 'signup.html', context={'form': form})

def login(request):
	form = LoginForm()
	if request.method == 'POST':
		form = LoginForm(request.POST)
		if form.is_valid():
			return login_user(request, form.cleaned_data['user'])
	context = {'form': form}
	if "m" in request.GET:
		context["message"] = request.GET["m"]
	return render(request, 'login.html', context=context)

def logout(request):
	return logout_user(request)


def account(request):
	if request.method == 'POST':
		form = ProfileForm(request.POST, instance=request.user.profile)
		form.save()
	else:
		form = ProfileForm(instance=request.user.profile)
	context = {'form': form}
	return render(request, 'account.html', context=context)
