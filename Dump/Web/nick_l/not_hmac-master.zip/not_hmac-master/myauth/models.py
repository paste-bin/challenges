from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
from django.core.urlresolvers import reverse

class Profile(models.Model):
	user = models.OneToOneField(User, related_name='profile')
	first_name = models.CharField(max_length=200, blank=True)
	last_name = models.CharField(max_length=200, blank=True)
	profile_img = models.URLField(verbose_name='Profile image URL', blank=True)
	is_confirmed = models.BooleanField(default=False)

	def message_count(self):
		return self.user.inbox.filter(read=False).count()

	def message_url(self):
		return reverse('send_message')+'?to=' + str(self.user.id)

	def approval_url(self):
		return reverse('user_approval')+'?approve=' + str(self.user.id)
