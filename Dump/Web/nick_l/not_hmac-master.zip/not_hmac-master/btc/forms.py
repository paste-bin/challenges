from django import forms
from django.contrib.auth import authenticate

class SearchForm(forms.Form):
	q = forms.CharField(label='Search')

class MessageForm(forms.Form):
	message = forms.CharField(label='Message', widget=forms.Textarea)
