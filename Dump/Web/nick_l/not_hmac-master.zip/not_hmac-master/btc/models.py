from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User

class Message(models.Model):
	sender = models.ForeignKey(User, related_name='sent_messages')
	to = models.ForeignKey(User, related_name='inbox')
	read = models.BooleanField(default=False)
	message = models.TextField()
