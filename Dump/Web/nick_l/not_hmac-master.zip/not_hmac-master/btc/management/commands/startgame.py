from django.core.management.base import BaseCommand
from django.core.urlresolvers import reverse
from django.conf import settings
from django.contrib.auth.models import User
from sessions.hmac import sign_uri

import requests
import time

class Command(BaseCommand):
	help = 'Simulates the actions of the admin user'

	def handle(self, *args, **options):
		self.admin = User.objects.get(username=settings.ADMIN1_NAME)
		while True:
			self.update()
			time.sleep(settings.LINK_EXPIRY_SECONDS)

	def get_fake_url(self):
		return "http://" + settings.HOSTNAME + sign_uri(reverse('read_messages'), self.admin)

	def update(self):
		referrer = self.get_fake_url()
		for message in self.admin.inbox.all():
			if message.sender.profile.profile_img:
				try:
					requests.get(message.sender.profile.profile_img, headers={'Referer': referrer})
				except:
					print "URL has some kind of issue", message.sender.profile.profile_img
