from django.core.management.base import BaseCommand
from django.conf import settings

from django.contrib.auth.models import User
from myauth.models import *
from btc.models import *
from sessions.models import *
import sessions

class Command(BaseCommand):
	help = 'Wipes all data and creates initial game data.'

	def handle(self, *args, **options):
		self.wipe()
		self.make_users()

	def wipe(self):
		to_delete = [User, Profile, Message, CryptoSecret]
		for model in to_delete:
			self.stdout.write("Deleting {}".format(model.__name__))
			model.objects.all().delete()

	def _make_user(self, username, password, is_staff=False, is_superuser=False):
		self.stdout.write("Creating user {} with password {}".format(
			username,
			password,
		))
		user = User.objects.create_user(username, password=password)
		if is_superuser:
			secret = sessions.hmac.generate_secret(length=settings.HMAC_SUPERUSER_KEY_LENGTH)
		else:
			secret = sessions.hmac.generate_secret()
		user.secret = CryptoSecret.objects.create(secret=secret, user=user)
		user.profile = Profile.objects.create(user=user, is_confirmed=True)
		user.is_staff = is_staff
		user.is_superuser = is_superuser
		user.save()
		return user

	def make_users(self):
		self.admin1 = self._make_user(settings.ADMIN1_NAME, settings.ADMIN1_PASSWORD, is_staff=True)
		self.admin2 = self._make_user(settings.ADMIN2_NAME, settings.ADMIN2_PASSWORD, is_staff=True, is_superuser=True)


