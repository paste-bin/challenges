from django.shortcuts import render, redirect
from django.core.urlresolvers import reverse
from sessions import hmac
from django.contrib.auth.models import User
from forms import SearchForm, MessageForm
from models import *
from myauth.models import Profile
import urllib

def home(request):
	return render(request, 'home.html', {})

def security(request):
	return render(request, 'security.html', {})

def search(request):
	context = {}
	if 'q' in request.GET:
		context['form'] = SearchForm(request.GET)
	else:
		context['form'] = SearchForm()
	if request.method == 'POST':
		url = reverse('search') + '?q=' + urllib.quote(request.POST['q'])
		if request.user.profile.is_confirmed:
			url += '&unconfirmed=0'
		else:
			url += '&unconfirmed=1'
		return redirect(hmac.sign_uri(url, request.user))
	elif 'q' in request.GET:
		filters = {'username__icontains': request.GET['q'], 'is_superuser': False}
		if request.GET['unconfirmed'] == '1':
			filters['is_staff'] = False
			context['blocked'] = True
		context['results'] = User.objects.filter(**filters)

	return render(request, 'search.html', context)

def send_message(request):
	context = {}
	if request.method == 'POST':
		form = MessageForm(request.POST)
		if form.is_valid():
			Message.objects.create(sender=request.user, to_id=request.GET["to"], message=form.cleaned_data["message"])
			return redirect(hmac.sign_uri(reverse('home'), request.user))
	else:
		form = MessageForm()
	context["to"] = User.objects.get(id=request.GET["to"])
	context["form"] = form
	return render(request, 'send.html', context)

def read_messages(request):
	context = {}
	messages = list(request.user.inbox.all().order_by('-id'))
	request.user.inbox.all().update(read=True)
	context["messages"] = messages
	return render(request, 'read.html', context)

def user_approval(request):
	context = {}
	if 'approve' in request.GET:
		Profile.objects.filter(user_id=int(request.GET['approve'])).update(is_confirmed=True)
	context["users"] = User.objects.all()

	if request.GET['show_super'] == '1':
		context['show_super'] = True
	return render(request, 'user_approval.html', context)


