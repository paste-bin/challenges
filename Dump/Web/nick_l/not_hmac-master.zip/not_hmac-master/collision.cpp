#include <cstdio>
#include <cstring>
#include <cstdlib>
#if defined(__APPLE__)
#  define COMMON_DIGEST_FOR_OPENSSL
#  include <CommonCrypto/CommonDigest.h>
#  define SHA1 CC_SHA1
#else
#  include <openssl/md5.h>
#endif

const char* ALPHABET = "abcdef0123456789";
const int NUM_PROCESSES = 8;
const char* TARGET = "d7058eba539c833fed12";
int alen;

// http://stackoverflow.com/questions/7627723/how-to-create-a-md5-hash-of-a-string-in-c
char *str2md5(const char *str, int length, char*out) {
    int n;
    MD5_CTX c;
    unsigned char digest[16];

    MD5_Init(&c);

    while (length > 0) {
        if (length > 512) {
            MD5_Update(&c, str, 512);
        } else {
            MD5_Update(&c, str, length);
        }
        length -= 512;
        str += 512;
    }

    MD5_Final(digest, &c);

    for (n = 0; n < 16; ++n) {
        snprintf(&(out[n*2]), 16*2, "%02x", (unsigned int)digest[n]);
    }

    return out;
}

void checkMD5(char* buffer) {
	char md5[33];
	char finalbuffer[1000] = "/user_approval/?show_super=0&user=16&xp=1458708013.93";
	strcat(finalbuffer, buffer);
	//strcat(finalbuffer, "3nptpowfzs");
	int len = strlen(finalbuffer);
	str2md5(finalbuffer, len, md5);
	int tlen = strlen(TARGET);
	int mlen = strlen(md5);
	if (!strcmp(md5 + mlen - tlen, TARGET)) {
		printf("%s\n", finalbuffer);
	} else if (rand() % 1000000 == 0) {
		printf(".");
		fflush(stdout);
	}
}

void crackMD5(const char *astart, int astartlen, char* buffer=NULL) {
	if (buffer == NULL) {
		buffer = (char*)malloc(200);
		memset(buffer, 0, 200);
	}
	int end = strlen(buffer);
	if (end == 7) {
		checkMD5(buffer);
		return;
	}
	for (int i = 0; i < astartlen; i++) {
		char candidate = astart[i];
		buffer[end] = candidate;
		if (end == 0) {
			printf("%s\n", buffer);
		}
		crackMD5(ALPHABET, alen, buffer);
		buffer[end] = 0;
	}
}

int main() {
	int children[NUM_PROCESSES];
	alen = strlen(ALPHABET);
	int allocated = 0;
	for (int i = 0; i < NUM_PROCESSES; i++) {
		if ((children[i] = fork()) == 0) {
			printf("Created child\n");
			crackMD5(ALPHABET+allocated, (alen-allocated) / (NUM_PROCESSES-i));
			return 0;
		}
		allocated += (alen-allocated) / (NUM_PROCESSES-i);
		printf("%d\n", children[i]);
	}
	for (int i = 0; i < NUM_PROCESSES; i++) {
		int status;
		printf("Waiting for %d\n", children[i]);
		while (waitpid(children[i], &status, WNOHANG|WUNTRACED) != children[i]) {
			sleep(1);
		}
	}

}