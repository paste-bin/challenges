# not_hmac

## about

The doesn't use cookies to authenticate users. Instead, it insecurely combines URLs and per-user keys into something it falsely calls a HMAC.
Many (but not all) permission checks are done by not linking to pages which a user doesn't have access to. This idea sort of makes sense,
but the app can also be tricked into signing some kinds of user-determined URLs.

## gettin' flags

1. Sign up as a new user.
1. Use the search to find users. Users with higher permissions than the current user are hidden from the search.
  * To bypass, search a&unconfirmed=0&unconfirmedz=
  * This takes you to http://localwargame.com:8000/search/?q=a%26unconfirmed%3D0%26unconfirmedz%3D&unconfirmed=1&xp=1458878416.35&user=27&hmac=bca643181b6949fdddc9
  * Modify URL to be http://localwargame.com:8000/search/?q=a&unconfirmed=0&unconfirmedz=%26unconfirmed%3D1&xp=1458878416.35&user=27&hmac=bca643181b6949fdddc9
  * The page now contains a flag
  * This exploits the fact that GET arguments aren't properly re-encoded when the HMAC arg is removed.
  * Only some arguments can be reset in this way because of how the arguments are sorted. Also the user can't be set because different users
    have different keys.
1. Use the account settings page to change profile image to a URL on a server which logs referrer URLs.
1. Send a message to the admin account you can find through enumerating the search.
1. Steal the admin session by visiting the URL in the referrer header, when the admin eventually checks their messages. This gives a flag.
1. The user management page reveals the keys of normal users, and the length of the key for admin users. There is a GET param which is hiding
   superusers.
1. Determine the algorithm used to generate the HMACs based on your normal-user URLs and the given normal-user secret.
1. Brute force the key for the admin account you've just taken over. Example C++ code is provided. Beware my shitty, uninformed UNIX
   process management. Use the key to sign a URL with show_super=1
1. This reveals the very-long key length for the mega-admin account. The id of the megaadmin account is also revealed through the message
   link, though it was already pretty predictable.
1. Throughout this, you may notice that when sessions expire, the user is sent to a login page, but the login page is signed for their
   user. The validity of the expired session is evaluated *after* the user logs in again. This can be exploited to sign arbitrary data
   with a certain prefix. This means that if you can generate two URLs with the same MD5 hash, you can get this endpoint to sign one of
   them, which will therefore sign the other. You can use this to take over any account. Using it to take over the admin account gives
   you a flag. Some projects such as hashclash claim to be able to generate chosen-prefix collisions, but I haven't been able to get any
   of them to work.
