#!/usr/bin/env python

import angr
p = angr.project.load_shellcode(open("main.bin").read(), "x86", start_offset=0x7C00, load_address=0x7C00)

state = p.factory.blank_state(addr=0x7C6F)
